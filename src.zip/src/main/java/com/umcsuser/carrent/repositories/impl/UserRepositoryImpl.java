package com.umcsuser.carrent.repositories.impl;

import com.google.gson.*;
import com.umcsuser.carrent.models.User;
import com.umcsuser.carrent.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

@Repository
@Profile("json")
public class UserRepositoryImpl implements UserRepository {
    private final Map<String, User> users = new HashMap<>();
    private final File jsonFile;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public UserRepositoryImpl(@Value("${carrent.json.users-file}") String filePath) {
        this.jsonFile = new File(filePath);
        load();
    }

    @Override
    public User getUser(String login) {
        return users.get(login);
    }

    @Override
    public List<User> getUsers() {
        return new ArrayList<>(users.values());
    }

    @Override
    public User update(User user) {
        users.put(user.getLogin(), user);
        save();
        return user;
    }

    @Override
    public boolean registerNewUser(String login, String password, String role) {
        if (users.containsKey(login)) {
            return false;
        }
        User newUser = new User(login, password, role);
        users.put(login, newUser);
        return true;
    }

    @Override
    public int removeUser(String login, User admin) {
        if (admin.getRole() != com.umcsuser.carrent.models.Role.ADMIN) {
            return 1;
        }

        User toRemove = users.get(login);
        if (toRemove == null) {
            return 1;
        }

        if (toRemove.getRentedVehicleId() != null && !toRemove.getRentedVehicleId().isEmpty()) {
            return 2;
        }

        users.remove(login);
        return 0;
    }

    @Override
    public void save() {
        try {
            JsonArray array = new JsonArray();
            for (User u : users.values()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id", u.getId());
                obj.addProperty("login", u.getLogin());
                obj.addProperty("passwordHash", u.getPassword());
                obj.addProperty("role", u.getRole().name());
                if (u.getRentedVehicleId() != null) {
                    obj.addProperty("rentedVehicleId", u.getRentedVehicleId());
                }
                array.add(obj);
            }
            
            String json = gson.toJson(array);
            Files.write(Paths.get(jsonFile.getPath()), json.getBytes());
            System.out.println("user repo save successful");
        } catch (IOException e) {
            System.out.println("error saving users!");
            e.printStackTrace();
        }
    }

    @Override
    public void load() {
        try {
            if (!jsonFile.exists()) {
                System.out.println("users.json not found");
                return;
            }

            String json = new String(Files.readAllBytes(Paths.get(jsonFile.getPath())));
            JsonArray array = gson.fromJson(json, JsonArray.class);
            
            if (array != null) {
                for (JsonElement element : array) {
                    JsonObject obj = element.getAsJsonObject();
                    
                    String login = obj.get("login").getAsString();
                    String id = obj.has("id") ? obj.get("id").getAsString() : null;
                    String password = obj.has("passwordHash")
                        ? obj.get("passwordHash").getAsString()
                        : (obj.has("password") ? obj.get("password").getAsString() : "");
                    String role = obj.has("role") ? obj.get("role").getAsString() : "USER";
                    String rentedVehicleId = obj.has("rentedVehicleId") && !obj.get("rentedVehicleId").isJsonNull()
                        ? obj.get("rentedVehicleId").getAsString()
                        : null;
                    
                    User user;
                    if (id != null) {
                        user = new User(id, login, password, role, rentedVehicleId);
                    } else {
                        user = new User(login, password, role);
                        if (rentedVehicleId != null) {
                            user.setRentedVehicleId(rentedVehicleId);
                        }
                    }
                    users.put(login, user);
                }
            }
        } catch (IOException e) {
            System.out.println("error loading user");
            e.printStackTrace();
        }
    }
}